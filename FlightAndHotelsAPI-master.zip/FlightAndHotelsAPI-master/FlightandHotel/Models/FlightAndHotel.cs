﻿using System;

namespace FlightandHotel.Models
{
    public class FlightAndHotel
    {
        public int ID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Email { get; set; }
        public string Details { get; set; }
    }
}