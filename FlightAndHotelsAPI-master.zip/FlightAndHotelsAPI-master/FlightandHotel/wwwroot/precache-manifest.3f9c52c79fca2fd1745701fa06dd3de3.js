self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "e0872eeec1b1e8d077ad",
    "url": "/static/js/main.e0872eee.chunk.js"
  },
  {
    "revision": "cf53177ea4095321f2b8",
    "url": "/static/js/1.cf53177e.chunk.js"
  },
  {
    "revision": "e0872eeec1b1e8d077ad",
    "url": "/static/css/main.4c5867bc.chunk.css"
  },
  {
    "revision": "cf53177ea4095321f2b8",
    "url": "/static/css/1.24bfa82c.chunk.css"
  },
  {
    "revision": "b570be8bf48dcdc405b3b60448afcd17",
    "url": "/index.html"
  }
];