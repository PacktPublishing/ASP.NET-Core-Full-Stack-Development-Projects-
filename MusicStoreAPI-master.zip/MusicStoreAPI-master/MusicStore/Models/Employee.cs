﻿using System;

namespace MusicStore.Models
{
    public class Employee
    {
        public int ID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Notes { get; set; }
    }
}
